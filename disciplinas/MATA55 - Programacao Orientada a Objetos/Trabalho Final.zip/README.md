## Schoolbus 
- Necessário manter main.py e schoolbus.py na mesma pasta
- Rode main.py e interaja com os menus

obs: talvez seja necessário instalar os pacotes datetime e uuid