import uuid
from abc import ABC, abstractmethod


class Endereco:

  def __init__(self, rua: str, numero: int, complemento: str, bairro: str):
    self._rua = rua
    self._numero = numero
    self._complemento = complemento
    self._bairro = bairro


class Pessoa(ABC):

  def __init__(self, nome_oficial: str, cpf_cnpj: str, endereco: Endereco,
               telefone: str):
    self._nome_oficial = nome_oficial
    self._cpf_cnpj = cpf_cnpj
    self._endereco = endereco
    self._telefone = telefone

  def apresentar_dados(self):
    print(f"Nome civil: {self._nome_oficial}")
    print(f"CPF/CNPJ: {self._cpf_cnpj}")
    print(
        f"Endereço: {self._endereco._rua}, {self._endereco._numero}, {self._endereco._complemento}, {self._endereco._bairro}"
    )
    print(f"Telefone: {self._telefone}")

  @abstractmethod
  def verificar_tipo():
    return "Pessoa"


class PessoaFisica(Pessoa):

  def __init__(self, nome_oficial: str, cpf_cnpj: str, endereco: Endereco,
               telefone: str, nome: str, pai: str, mae: str, naturalidade: str,
               data_nascimento):
    super().__init__(nome_oficial, cpf_cnpj, endereco, telefone)
    self._nome = nome
    self._pai = pai
    self._mae = mae
    self._naturalidade = naturalidade
    self._data_nascimento = data_nascimento

  def apresentar_dados(self):
    super().apresentar_dados()
    print(f"Nome social: {self._nome}")
    print(f"Nome do pai: {self._pai}")
    print(f"Nome da mãe: {self._mae}")
    print(f"Naturalidade: {self._naturalidade}")
    print(f"Data de nascimento: {self._data_nascimento}")

  def get_cpf(self):
    return self._cpf_cnpj

  def get_nome_civil(self):
    return self._nome_oficial


class PessoaJuridica(Pessoa):

  def __init__(self, nome_oficial: str, cpf_cnpj: str, endereco: Endereco,
               telefone: str, nome_fantasia: str, num_funcionarios: int):
    super().__init__(nome_oficial, cpf_cnpj, endereco, telefone)
    self._nome_fantasia = nome_fantasia
    self._num_funcionarios = num_funcionarios

  def get_cnpj(self):
    return self._cpf_cnpj

  def get_nome_fantasia(self):
    return self._nome_fantasia


class Motorista(PessoaFisica):

  def __init__(self, nome_oficial: str, cpf_cnpj: str, endereco: Endereco,
               telefone: str, nome: str, pai: str, mae: str, naturalidade: str,
               data_nascimento, num_habilitacao: str, cat_habilitacao: str,
               tipo: int, num_contrato):
    super().__init__(nome_oficial, cpf_cnpj, endereco, telefone, nome, pai,
                     mae, naturalidade, data_nascimento)
    self._num_habilitacao = num_habilitacao
    self._cat_habilitacao = cat_habilitacao
    self._tipo = tipo
    self._id = uuid.uuid1()
    if tipo == 1:
      self._num_contrato = num_contrato

  def apresentar_dados(self):
    super().apresentar_dados()
    print(f"Número de habilitação: {self._num_habilitacao}")
    print(f"Categoria de habilitação: {self._cat_habilitacao}")
    print(f"Tipo: {self._tipo}")

  def verificar_tipo():
    return "Motorista"

  def servidor_terceirizado(self):
    if self._tipo == 0:
      print("Servidor")
    else:
      "Terceiriado"

  def set_num_contrato(self, num: int):
    self._num_contrato = num if num > 0 else print("Método inválido")


class Escola(PessoaJuridica):

  def __init__(self, nome_oficial: str, cpf_cnpj: str, endereco: Endereco,
               telefone: str, nome_fantasia: str, num_funcionarios: int):
    super().__init__(nome_oficial, cpf_cnpj, endereco, telefone, nome_fantasia,
                     num_funcionarios)
    self._alunos = []
    self._id = uuid.uuid1()

  def verificar_tipo():
    return "Escola"

  def apresentar_dados(self):
    super().apresentar_dados()
    print(f"Número de alunos: {len(self._alunos)}")

  def matricular_aluno(self, aluno):
    self._alunos.append(aluno)

  def imprime_alunos(self):
    for aluno in self._alunos:
      print(f"Aluno: {aluno._nome}")
      print(f"CPF: {aluno._cpf_cnpj}")
      print(f"Nome Social: {aluno._nome_social}")
      print(f"Série: {aluno._serie}")


class PontoParada:
  PontosCriados = 0

  def __init__(self, nome: str, latitude: float, longitude: float, alunos=[]):
    self._nome = nome
    self._latitude = latitude
    self._longitude = longitude
    PontoParada.PontosCriados += 1
    self._id = PontoParada.PontosCriados
    self._alunos = alunos

  @staticmethod
  def total_pontos():
    print(f"Total de Pontos de Parada: {PontoParada.PontosCriados}")

  def apresentar_dados(self):
    print(f"Nome: {self._nome}")
    print(f"Latitude: {self._latitude}")
    print(f"Longitude: {self._longitude}")
    print(f"ID: {self._id}")


class Rota:
  RotasCriadas = 0

  def __init__(self, pontos: list[PontoParada]):
    self._pontos_parada = pontos
    Rota.RotasCriadas += 1
    self._id = Rota.RotasCriadas

  @staticmethod
  def total_rotas():
    print(f"Total de Rotas: {Rota.RotasCriadas}")

  def demanda(self):
    demanda = 0
    for pp in self._pontos_parada:
      demanda += len(pp._alunos)
    return demanda


class Aluno(PessoaFisica):

  def __init__(self, nome_oficial: str, cpf_cnpj: str, endereco: Endereco,
               telefone: str, nome: str, pai: str, mae: str, naturalidade: str,
               data_nascimento, matricula: int, serie: str, escola,
               ponto_parada):
    super().__init__(nome_oficial, cpf_cnpj, endereco, telefone, nome, pai,
                     mae, naturalidade, data_nascimento)
    self._matricula = matricula
    self._serie = serie
    self._escola = escola
    self._ponto_parada = ponto_parada
    self._id = uuid.uuid1()

  def apresentar_dados(self):
    super().apresentar_dados()
    print(f"Matrícula: {self._matricula}")
    print(f"Série: {self._serie}")
    print(f"Escola: {self._escola._nome_fantasia}")
    print(f"Ponto de Parada: {self._ponto_parada._nome}")

  def verificar_tipo():
    return "Aluno"


class Veiculo:

  def __init__(self, placa: str, ano: int, modelo: str, capacidade: int,
               tipo: int, num_contrato: int):
    self._placa = placa
    self._ano = ano
    self._modelo = modelo
    self._capacidade = capacidade
    self._tipo = tipo
    self._id = uuid.uuid1()
    if tipo == 1:
      self._num_contrato = num_contrato

  def verificar_tipo():
    return "Veículo"

  def __eq__(self, other_v):
    if self._placa == other_v._placa:
      return True
    return False

  def set_num_contrato(self, num):
    self._num_contrato = num

  def proprio_alugado(self):
    if self._tipo == 0:
      print("Próprio")
    else:
      "Alugado"


class Fornecedor(PessoaJuridica):

  def __init__(self,
               nome_oficial: str,
               cpf_cnpj: str,
               endereco: Endereco,
               telefone: str,
               nome_fantasia: str,
               num_funcionarios: int,
               contratos=[]):
    super().__init__(nome_oficial, cpf_cnpj, endereco, telefone, nome_fantasia,
                     num_funcionarios)
    self._contratos = contratos
    self._id = uuid.uuid1()

  def adicionar_contrato(self, contrato):
    self._contratos.append(contrato)

  def apresentar_dados(self):
    super().apresentar_dados()
    print(f"Número de contratos: {len(self._contratos)}")

  def verificar_tipo():
    return "Fornecedor"


class Contrato:

  def __init__(self, num_contrato, data_inicio, data_fim, valor: float,
               fornecedor):
    self._num_contrato = num_contrato
    self._data_inicio = data_inicio
    self._data_fim = data_fim
    self._valor = valor
    self._veiculos = []
    self._motoristas = []
    self._id = uuid.uuid1()
    if fornecedor:
      self._fornecedor = fornecedor
      self._fornecedor._contratos.append(self)

  def set_num_contrato(self):
    num = 0
    while (num < 1):
      num = int(input("Digite o número do contrato: "))
      if num >= 1:
        break
      print("Método inválido, tente novamente")
    self._num_contrato = num

  def adicionar_veiculo(self, veic: Veiculo):
    if veic._tipo == 1:
      veic.set_num_contrato(self._num_contrato)
      self._veiculos.append(veic)
      return
    print("Impossível adicionar veiculo próprio em contrato externo")

  def remover_veiculo(self, veic: Veiculo):
    for v in self._veiculos:
      if v == veic:
        self._veiculos.remove(v)

  def adicionar_motorista(self, mot: Motorista):
    if mot._tipo == 1:
      mot.set_num_contrato(self._num_contrato)
      self._veiculos.append(mot)
      return
    print("Impossível adicionar motorista contratado em contrato externo")

  def remover_motorista(self, mot: Motorista):
    for m in self._motoristas:
      if m == mot:
        self._motoristas.remove(m)

  def adicionar_fornecedor(self, pj: PessoaJuridica):
    if isinstance(pj, Fornecedor):
      pj.adicionar_contrato(self)
      self._fornecedor = pj
      return
    print("Impossível adicionar PJ não fornecedor em contrato externo")
