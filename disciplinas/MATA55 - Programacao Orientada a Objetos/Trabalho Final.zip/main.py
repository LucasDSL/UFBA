from datetime import datetime
from schoolbus import Rota, PontoParada, Escola, Aluno, Motorista, Endereco, Fornecedor, Contrato, Veiculo

pessoas_fisicas = []
pessoas_juridicas = []
pontos_parada = []
veiculos = []
rotas = []
contratos = []


def select_contratos():
  for ct in contratos:
    ct.apresentar_dados()
  select = input(
      "Digite id dos contratos que deseja selecionar separados por /")
  select = select.split("/")
  contratos_selecionados = []
  for ct in contratos:
    for sl in select:
      if ct._id == sl:
        contratos_selecionados.append(ct)
  return contratos_selecionados


def get_endereco():
  print("Insira os dados do endereço")
  rua = input("Rua: ")
  numero = int(input("Número: "))
  complemento = input("Complemento: ")
  bairro = input("Bairro: ")
  return Endereco(rua, numero, complemento, bairro)


def escolher_ponto_parada():
  for pp in pontos_parada:
    pp.apresentar_dados()
    print("Desejar adicionar esse ponto de parada? (1 - Sim 0 - Não)")
    if int(input()) == 1:
      return pp


def criar_ponto_parada():
  nome = input("Digite o nome do ponto de parada: ")
  latitude = float(input("Digite a latitude do ponto de parada: "))
  longitude = float(input("Digite a longitude do ponto de parada: "))
  ponto_parada = PontoParada(nome, latitude, longitude)
  pontos_parada.append(ponto_parada)
  return ponto_parada


def escolher_escola():
  escola_id = input("Digite o id da escola:")
  for esc in pessoas_juridicas:
    if isinstance(esc, Escola) and esc._id == escola_id:
      return esc


def criar_pessoa():
  print("1 - Pessoa Física")
  print("2 - Pessoa Jurídica")
  opcao = int(input("Escolha uma opção: "))
  print("Digite as informações básicas da pessoa")
  nome_oficial = input("Nome: ")
  cpf_cnpj = input("CPF/CNPJ: ")
  endereco = get_endereco()
  telefone = input("Telefone: ")
  if opcao == 1:
    print("Dados específicos de Pessoa Física:")
    nome_social = input("Nome Social: ")
    pai = input("Nome do Pai: ")
    mae = input("Nome da Mãe: ")
    naturalidade = input("Naturalidade: ")
    nascimento = input("Data de Nascimento (dd/mm/aaaa): ")
    nascimento = datetime.strptime(nascimento, "%d/%m/%Y")
    print("Deseja criar Aluno ou Motorista?")
    print("1 - Aluno / 2 - Motorista")
    op = int(input())
    if op == 1:
      print("Dados específicos de Aluno:")
      matricula = int(input("Matrícula: "))
      serie = input("Série: ")
      pp = int(
          input(
              "Deseja escolher ou criar ponto de parada? 1 - Escolher 2 - Criar"
          ))
      if pp == 1:
        pp = escolher_ponto_parada()
      else:
        pp = criar_ponto_parada()
      escola = escolher_escola()
      aluno = Aluno(nome_oficial, cpf_cnpj, endereco, telefone, nome_social,
                    pai, mae, naturalidade, nascimento, matricula, serie,
                    escola, pp)
      pessoas_fisicas.append(aluno)
    else:
      print("Dados específicos de Motorista:")
      num_habilitacao = input("Número de Habilitação: ")
      cat_habilitacao = input("Categoria de Habilitação: ")
      tipo = int(input("Tipo de motorista? 1 - Terceirizado 0 - Servidor"))
      num_contrato = None
      if tipo == 1:
        num_contrato = int(input("Digite o número do contrato"))
      motorista = Motorista(nome_oficial, cpf_cnpj, endereco, telefone,
                            nome_social, pai, mae, naturalidade, nascimento,
                            num_habilitacao, cat_habilitacao, tipo,
                            num_contrato)
      pessoas_fisicas.append(motorista)

  else:
    print("Dados específicos de Pessoa jurídica")
    nome_fantasia = input("Digite o nome fantasia:")
    num_funcionarios = int(input("Digite o número de funcionários:"))
    print("Deseja criar Fornecedor ou Escola?")
    op = int(input("1 - Fornecedor / 2 - Escola"))
    if op == 1:
      ctsf = select_contratos()
      fornecedor = Fornecedor(nome_oficial, cpf_cnpj, endereco, telefone,
                              nome_fantasia, num_funcionarios, ctsf)
      pessoas_juridicas.append(fornecedor)
    else:
      escola = Escola(nome_oficial, cpf_cnpj, endereco, telefone,
                      nome_fantasia, num_funcionarios)
      pessoas_juridicas.append(escola)


def criar_veiculo():
  print("Digite os dados do veículo")
  placa = input("Placa: ")
  modelo = input("Modelo: ")
  ano = int(input("Ano: "))
  capacidade = int(input("Capacidade: "))
  num_contrato = int(input("Número do contrato: "))
  tipo = int(input("Tipo: 1 - Alugado / 0 - Próprio"))
  veiculo = Veiculo(placa, ano, modelo, capacidade, tipo, num_contrato)
  veiculos.append(veiculo)


def criar_entidade():
  print("1 - Criar Veículo")
  print("2 - Criar Contrato")
  print("3 - Criar Ponto Parada")
  op = int(input("Escolha uma opção:"))
  if op == 1:
    criar_veiculo()
  elif op == 2:
    criar_contrato()
  elif op == 3:
    criar_ponto_parada()
  else:
    return


def criar_rota():
  print("Opções para criação de rota:")
  pps = []
  while True:
    print("1 - Criar novo ponto de parada")
    print("2 - Escolher dos pontos de parada existentes")
    print("3 - Criar rota com pontos selecionados")
    print("4 - Ver pontos selecionados")
    op = int(input("Digite a opção desejada: "))
    if op == 1:
      pps.append(criar_ponto_parada())
    elif op == 2:
      for pp in pontos_parada:
        pp.apresentar_dados()
        print("Desejar adicionar esse ponto de parada? (1 - Sim 0 - Não)")
        if int(input()) == 1:
          pps.append(pp)
    elif op == 3:
      break
    else:
      for pp in pps:
        pp.apresentar_dados()
  rotas.append(Rota(pps))


def escolher_fornecedor():
  fornecedor = None
  for pj in pessoas_juridicas:
    if isinstance(pj, Fornecedor):
      pj.apresentar_dados()
      print()
  cnpj = input("Digite o CNPJ do fornecedor desejado: ")
  for pj in pessoas_juridicas:
    if isinstance(pj, Fornecedor) and pj._cpf_cnpj == cnpj:
      fornecedor = pj
  return fornecedor


def criar_contrato():
  num = int(input("Digite o número do contrato: "))
  data_inicio = input("Digite a data de início do contrato (YYYY/MM/DD): ")
  data_inicio = data_inicio.split("/")
  data_inicio = datetime(int(data_inicio[0]), int(data_inicio[1]),
                         int(data_inicio[2]))
  data_fim = input("Digite a data de término do contrato (YYYY/MM/DD): ")
  data_fim = data_fim.split("/")
  data_fim = datetime(int(data_fim[0]), int(data_fim[1]), int(data_fim[2]))
  valor = float(input("Digite o valor do contrato:"))
  print("Escolha o fornecedor para o contrato:")
  fn = escolher_fornecedor()
  contrato = Contrato(num, data_inicio, data_fim, valor, fn)
  contratos.append(contrato)


def demanda_rota_especifica(id_rota):
  for rota in rotas:
    if rota._id == id_rota:
      print(f"Rota com demanda total de {rota.demanda_rota()} alunos")
      return
  print("Rota com id especifcado não encontrada")


def busca_pessoa():
  uid = input("Digite uid/id da pessoa(física ou jurídica): ")
  for pj in pessoas_juridicas:
    if pj._id == uid:
      return pj
  for pf in pessoas_fisicas:
    if pf._id == uid:
      return pf
  print("Pessoa com id não encontrada!")


def detalhar():
  pessoa = busca_pessoa()
  if pessoa is not None:
    pessoa.apresentar_dados()


def exibir_tipo():
  pessoa = busca_pessoa()
  if pessoa is not None:
    pessoa.verificar_tipo()


def menu() -> None:
  while True:
    print("1 - Criar Pessoa ou Entidade")
    print("2 - Criar Contrato")
    print("3 - Detalhar pessoa com id específico")
    print("4 - Exibir tipo de pessoa com id específico")
    print("5 - Criar Rota")
    print("6 - Demanda de uma rota específica")
    print("7 - Imprimir quantidade de Rotas")
    print("8 - Imprimir quantidade de Pontos de Parada")
    print("9 - Sair")
    print("Escolha uma das opções:")
    entry = int(input())
    if entry == 1:
      print("Opções de criação")
      print("1 - Criar Pessoa(Aluno/Motorista/Escola/Fornecedor)")
      print("2 - Criar Entidade(Veículo/Ponto de Parada/Contrato)")
      op = int(input())
      if op == 1:
        criar_pessoa()
      else:
        criar_entidade()
    elif entry == 2:
      criar_contrato()
    elif entry == 3:
      detalhar()
    elif entry == 4:
      exibir_tipo()
    elif entry == 5:
      criar_rota()
    elif entry == 6:
      id_rota = int(input("Digite o id da rota: "))
      demanda_rota_especifica(id_rota)
    elif entry == 7:
      Rota.total_rotas()
    elif entry == 8:
      PontoParada.total_pontos()
    else:
      break


menu()
