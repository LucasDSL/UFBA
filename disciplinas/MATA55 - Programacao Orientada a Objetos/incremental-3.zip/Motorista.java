import java.util.*;
public class Motorista {
  private String nome_civil, nome_social, mae, pai, naturalidade, cpf_cnpj;
  private String rua, complemento, bairro, telefone;
  private Integer numero;
  private Date data_nascimento;
  private String num_habilitacao, cat_habilitacao;
  private Integer tipo, num_contrato;
  private ArrayList<Contrato> contratos;

  public Motorista(String nome_civil, String nome_social, String mae, String pai, String naturalidade, String cpf_cnpj,
      String rua, String complemento, String bairro, String telefone, Integer numero, Date data_nascimento,
      String num_habilitacao, String cat_habilitacao, Integer tipo, Integer num_contrato) {
    this.nome_civil = nome_civil;
    this.nome_social = nome_social;
    this.mae = mae;
    this.pai = pai;
    this.naturalidade = naturalidade;
    this.cpf_cnpj = cpf_cnpj;
    this.rua = rua;
    this.complemento = complemento;
    this.bairro = bairro;
    this.telefone = telefone;
    this.numero = numero;
    this.data_nascimento = data_nascimento;
    this.num_habilitacao = num_habilitacao;
    this.cat_habilitacao = cat_habilitacao;
    this.tipo = tipo;
    if (tipo == 1) {
      this.num_contrato = num_contrato;
    }
  }

  public String getNomeCivil() {
    return this.nome_civil;
  }

  public void setNomeCivil(String nome_civil) {
    this.nome_civil = nome_civil;
  }

  public String getNomeSocial() {
    return this.nome_social;
  }

  public void setNomeSocial(String nome_social) {
    this.nome_social = nome_social;
  }

  public String getMae() {
    return this.mae;
  }

  public void setMae(String mae) {
    this.mae = mae;
  }

  public String getPai() {
    return this.pai;
  }

  public void setPai(String pai) {
    this.pai = pai;
  }

  public String getNaturalidade() {
    return this.naturalidade;
  }

  public void setNaturalidade(String naturalidade) {
    this.naturalidade = naturalidade;
  }

  public String getCpf_cnpj() {
    return this.cpf_cnpj;
  }

  public void setCpf_cnpj(String cpf_cnpj) {
    this.cpf_cnpj = cpf_cnpj;
  }

  public String getNum_habilitacao() {
    return this.num_habilitacao;
  }

  public void setNum_habilitacao(String num_habilitacao) {
    this.num_habilitacao = num_habilitacao;
  }

  public String getCat_habilitacao() {
    return this.cat_habilitacao;
  }

  public void setCat_habilitacao(String cat_habilitacao) {
    this.cat_habilitacao = cat_habilitacao;
  }

  public String getDetailedTipo() {
    if (this.getTipo() == 1) {
      return "terceirizado";
    }
    return "servidor";
  }

  public Integer getTipo() {
    return this.tipo;
  }

  public void setTipo(Integer tipo) {
    if (tipo == 1 || tipo == 2) {
      this.tipo = tipo;
    } else {
      System.out.println("Método inválido.");
    }
  }

  public Integer getNumContrato() {
    return this.num_contrato;
  }

  public void setNumContrato(Integer num_contrato) {
    if (this.getTipo() == 1) {
      this.num_contrato = num_contrato;
    } else {
      System.out.println("Tipo inválido");
    }
  }

  public Date getDataNascimento() {
    return this.data_nascimento;
  }

  public void setDataNascimento(Date data_nascimento) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(data_nascimento);
    if (calendar.get(Calendar.YEAR) > 1900) {
      this.data_nascimento = data_nascimento;
    } else {
      System.out.println("Data inválida");
    }
  }

  public String getRua() {
    return this.rua;
  }

  public void setRua(String rua) {
    if (rua.length() > 0) {
      this.rua = rua;
    } else {
      System.out.println("Rua inválida");
    }
  }

  public String getComplemento() {
    return this.complemento;
  }

  public void setComplemento(String complemento) {
    if (complemento.length() > 0) {
      this.complemento = complemento;
    } else {
      System.out.println("Complemento inválido");
    }
  }

  public String getBairro() {
    return this.bairro;
  }

  public void setBairro(String bairro) {
    if (bairro.length() > 0) {
      this.bairro = bairro;
    } else {
      System.out.println("Bairro inválido");
    }
  }

  public String getTelefone() {
    return this.telefone;
  }

  public void setTelefone(String telefone) {
    if (telefone.length() > 0) {
      this.telefone = telefone;
    } else {
      System.out.println("Telefone inválido");
    }
  }

  public Integer getNumero() {
    return this.numero;
  }

  public void setNumero(Integer numero) {
    if (numero > 0) {
      this.numero = numero;
    } else {
      System.out.println("Número inválido");
    }
  }
}