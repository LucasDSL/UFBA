import java.util.*;
class Aluno {
  private String nome_civil, nome_social, pai, naturalidade, cpf, rua, complemento, bairro, telefone, serie;
  private Integer matricula, numeroCasa;
  private Rota rota;
  private Escola escola;

  public Aluno(String nome_civil, String nome_social, String pai, String naturalidade, String cpf, String rua, String complemento, String bairro, String telefone, String serie, Integer matricula, Integer numeroCasa) {
    this.nome_civil = nome_civil; 
    this.nome_social = nome_social;
    this.pai = pai; 
    this.naturalidade = naturalidade;
    this.cpf = cpf; 
    this.rua = rua;
    this.complemento = complemento;
    this.bairro = bairro;
    this.telefone = telefone; 
    this.serie = serie;
    this.matricula = matricula;
    this.numeroCasa = numeroCasa;
  }

  public String getCpf() {
    return this.cpf;
  }
  public String getNomeSocial() {
    return this.nome_social;
  }
  public String getSerie() {
    return this.serie;
  }
}