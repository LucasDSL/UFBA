import java.util.*;

public class Veiculo {
  private String placa, modelo;
  private Integer ano, capacidade, tipo, num_contrato;
  private Contrato contrato;
  
  public Veiculo(String placa, String modelo, Integer ano, Integer capacidade, Integer tipo, Integer num_contrato) {
    this.placa = placa;
    this.modelo = modelo;
    this.ano = ano;
    this.capacidade = capacidade;
    this.tipo = tipo;
    if (tipo == 1) {
      this.num_contrato = num_contrato;
    }
  }

  public String getPlaca() {
    return placa;
  }

  public void setPlaca(String placa) {
    this.placa = placa;
  }

  public String getModelo() {
    return modelo;
  }

  public void setModelo(String modelo) {
    this.modelo = modelo;
  }

  public Integer getAno() {
    return ano;
  }

  public void setAno(Integer ano) {
    this.ano = ano;
  }

  public Integer getCapacidade() {
    return capacidade;
  }

  public void setCapacidade(Integer capacidade) {
    this.capacidade = capacidade;
  }

  public Integer getTipo() {
    return tipo;
  }

  public void setTipo(Integer tipo) {
    this.tipo = tipo;
  }

  public Integer getNumContrato() {
    return num_contrato;
  }

  public void setNumContrato(Integer num_contrato) {
    if (this.getTipo() == 1) {
      this.num_contrato = num_contrato;
    } else {
      System.out.println("Método inválido.");
    }
  }

  public String getDetailedTipo() {
    if (this.getTipo() == 1) {
      return "alugado";
    }
    return "próprio";
  }

}