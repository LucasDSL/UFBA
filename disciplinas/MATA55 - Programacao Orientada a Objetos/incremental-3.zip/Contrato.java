import java.util.*;
class Contrato {
  private Integer num_contrato;
  private Date data_inicio, data_fim;
  private double valor;
  private ArrayList<Motorista> motoristas;
  private ArrayList<Veiculo> veiculos;

  public Contrato(Integer num_contrato, Date data_inicio, Date data_fim, double valor) {
    this.num_contrato = num_contrato;
    this.data_inicio = data_inicio;
    this.data_fim = data_fim;
    this.valor = valor;
  }

  
  public boolean addRelation(Motorista motorista) {
    if(motorista.getDetailedTipo() == "terceirizado") {
      this.motoristas.add(motorista);
      return true;
    }
    return false;
  }
  
  public boolean addRelation(Veiculo veiculo) {
    if(veiculo.getDetailedTipo() == "alugado") {
      this.veiculos.add(veiculo);
      return true;
    }
    return false;
  }

  public boolean removeRelation(Motorista motorista) {
    for(Iterator<Motorista> it = this.motoristas.iterator(); it.hasNext();) {
      Motorista mot = it.next();
      if(mot.getCpf_cnpj() == motorista.getCpf_cnpj()) {
        it.remove();
        return true;
      }
    }
    return false;
  }

  public boolean removeRelation(Veiculo veiculo) {
    for(Iterator<Veiculo> it = this.veiculos.iterator(); it.hasNext();) {
      Veiculo v = it.next();
      if(v.getPlaca() == veiculo.getPlaca()) {
        it.remove();
        return true;
      }
    }
    return false;
  }
}