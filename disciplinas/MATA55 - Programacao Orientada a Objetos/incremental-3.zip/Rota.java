import java.util.*;
class Rota {
}