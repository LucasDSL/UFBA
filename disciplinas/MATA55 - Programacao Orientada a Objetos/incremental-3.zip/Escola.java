import java.util.*;

class Escola {
  private String nome, cnpj, telefone;
  private Endereco endereco;
  private ArrayList<Aluno> alunos;

  public Escola(String nome, String cnpj, String telefone) {
    this.nome = nome;
    this.cnpj = cnpj;
    this.telefone = telefone;
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getCnpj() {
    return cnpj;
  }

  public void setCnpj(String cnpj) {
    this.cnpj = cnpj;
  }

  public String getTelefone() {
    return telefone;
  }

  public void setTelefone(String telefone) {
    this.telefone = telefone;
  }

  public Endereco getEndereco() {
    return endereco;
  }

  public void setEndereco(Endereco endereco) {
    this.endereco = endereco;
  }

  public boolean matricularAluno(Aluno aluno) {
    this.alunos.add(aluno);
    return true;
  }

  public void listarAlunos() {
    System.out.println("LISTANDO ALUNOS ..................\n\n");
    for(Aluno al: this.alunos) {
      System.out.println("ALUNO: "+al.getNomeSocial());
      System.out.println("CPF: "+al.getCpf());
      System.out.println("SÉRIE: "+al.getSerie());
      System.out.println("\n");
    }
  }
}