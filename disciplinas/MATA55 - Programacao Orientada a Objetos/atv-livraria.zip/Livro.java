class Livro {
  private String titulo, autor, area;
  private double preco;
  private int quantidadeEstoque;

  public Livro(String titulo, String autor, String area, double preco, int quantidade) {
    this.titulo = titulo;
    this.autor = autor;
    this.area = area;
    this.preco = preco;
    this.quantidadeEstoque = quantidade;
  }

  public String getTitulo() {
    return titulo;
  }

  public void setTitulo(String titulo) {
    this.titulo = titulo;
  }

  public String getAutor() {
    return autor;
  }

  public void setAutor(String autor) {
    this.autor = autor;
  }

  public String getArea() {
    return area;
  }

  public void setArea(String area) {
    this.area = area;
  }

  public double getPreco() {
    return preco;
  }

  public void setPreco(float preco) {
    this.preco = preco;
  }

  public int getQuantidade() {
    return quantidadeEstoque;
  }

  public void setQuantidade(int quantidadeEstoque) {
    this.quantidadeEstoque = quantidadeEstoque;
  }
}