import java.util.ArrayList;
import java.util.Iterator;

class Livraria {
  private String nome, cnpj;
  private ArrayList<Livro> livros;

  public Livraria(String nome, String cnpj) {
    this.nome = nome;
    this.cnpj = cnpj;
    this.livros = new ArrayList<Livro>();
  }

  public String getNome() {
    return nome;
  }

  public void setNome(String nome) {
    this.nome = nome;
  }

  public String getCnpj() {
    return cnpj;
  }

  public void setCnpj(String cnpj) {
    this.cnpj = cnpj;
  }

  public void addLivro(Livro livro) {
    if(livro.getArea() == null) {
      livro.setArea("multidisciplinar");
      this.livros.add(livro);
      return;
    }
    this.livros.add(livro);
    
  }

  public boolean registraCompra(String titulo, int quantidade){
    for(Iterator<Livro> it = this.livros.iterator(); it.hasNext();){
      Livro currentLivro = it.next();
      int currentLivroQuantidade = currentLivro.getQuantidade();
      if(titulo == currentLivro.getTitulo() && currentLivroQuantidade >= quantidade){
        currentLivro.setQuantidade(currentLivroQuantidade - quantidade);
        return true;
      }
    }
    return false;
  } 

  public void consultaLivro(String titulo){
    for(Iterator<Livro> it = this.livros.iterator(); it.hasNext();){
      Livro currentLivro = it.next();
      int currentLivroEstoque = currentLivro.getQuantidade();
      if(titulo.equals(currentLivro.getTitulo()) && currentLivroEstoque > 0){
        System.out.println("TITULO: "+currentLivro.getTitulo());
        System.out.println("PRECO: "+currentLivro.getPreco());
        System.out.println("ESTOQUE: "+currentLivro.getQuantidade());
        System.out.println("\n");
        return;
      } else if(titulo == currentLivro.getTitulo()){
        System.out.println("Sem estoque, deseja fazer pedido de novos exemplares?\n");
        return;
      }
    }
    System.out.println("Título não faz parte do nosso catálogo\n");
  } 

  public void listagemMensal(){
    int livrosComEstoque = 0;
    int totalLivrosEstoque = 0;
    for(Iterator<Livro> it = this.livros.iterator(); it.hasNext();){
      Livro currentLivro = it.next();
      int currentLivroEstoque = currentLivro.getQuantidade();
      if(currentLivroEstoque > 0){
        livrosComEstoque += 1;
        totalLivrosEstoque += currentLivroEstoque;
      }
      System.out.println("TITULO: "+currentLivro.getTitulo());
      System.out.println("AUTOR: "+currentLivro.getAutor());
      System.out.println("AREA: "+currentLivro.getArea());
      System.out.println("PRECO: "+currentLivro.getPreco());
      System.out.println("ESTOQUE: "+currentLivro.getQuantidade());
      System.out.println("\n");
    }
    System.out.println("LIVROS COM ESTOQUE: "+livrosComEstoque);
    System.out.println("ESTOQUE DE LIVROS: "+totalLivrosEstoque+"\n");
  } 
}